function extractUniqueCharacters(str) {
    // Use a Set to store unique characters
    const uniqueChars = new Set(str);
    
    // Convert the Set back to a string
    return [...uniqueChars].join('');
}

// Example usage
const exampleString2 = 'thequickbrownfoxjumpsoverthelazydog';
console.log(extractUniqueCharacters(exampleString2)); // Output: 'thequickbrownfxjmpsvlazydg'
