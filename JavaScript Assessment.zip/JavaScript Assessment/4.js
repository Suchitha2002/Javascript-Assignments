// Arrow function for multiplication
const multiply = (a, b) => a * b;

// Arrow function for division
const divide = (a, b) => {
    if (b === 0) {
        throw new Error('Division by zero is not allowed.');
    }
    return a / b;
};


const num1 = 10;
const num2 = 5;

console.log(`Multiplication of ${num1} and ${num2}: ${multiply(num1, num2)}`);
console.log(`Division of ${num1} by ${num2}: ${divide(num1, num2)}`);
