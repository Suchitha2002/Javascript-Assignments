function generateRandomId(length) {
    // Define the character list
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = '';

    // Loop to generate the random string
    for (let i = 0; i < length; i++) {
        // Get a random index from the characters list
        const randomIndex = Math.floor(Math.random() * characters.length);
        // Append the character at the random index to the result
        result += characters[randomIndex];
    }

    return result;
}


const idLength = 8;
const randomId = generateRandomId(idLength);

console.log(randomId); 
