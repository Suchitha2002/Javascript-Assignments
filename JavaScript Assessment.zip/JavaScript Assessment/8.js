function swapFirstAndLast(arr) {
    // Check if the array length is at least 1
    if (arr.length < 2) {
        // If the array has less than 2 elements, there's nothing to swap
        return arr;
    }

    // Swap the first and last elements
    const firstElement = arr[0];
    const lastElement = arr[arr.length - 1];
    
    arr[0] = lastElement;
    arr[arr.length - 1] = firstElement;

    return arr;
}

// Sample inputs and outputs
const array1 = [1, 2, 3, 4, 5];
const array2 = [10];
const array3 = [7, 14, 21, 28];

console.log(`Original Array: ${array1}`);
console.log(`Modified Array: ${swapFirstAndLast(array1)}`); // Output: [5, 2, 3, 4, 1]

console.log(`Original Array: ${array2}`);
console.log(`Modified Array: ${swapFirstAndLast(array2)}`); // Output: [10] (No change, single element)

console.log(`Original Array: ${array3}`);
console.log(`Modified Array: ${swapFirstAndLast(array3)}`); // Output: [28, 14, 21, 7]
