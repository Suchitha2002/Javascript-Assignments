const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Generate a random integer between 1 and 10
const randomNumber = Math.floor(Math.random() * 10) + 1;

// Prompt user for their guess
rl.question('Guess a number between 1 and 10: ', (answer) => {
    const userGuess = parseInt(answer, 10);

    if (userGuess === randomNumber) {
        console.log('Good Work');
    } else {
        console.log('Not matched');
    }

    // Close the readline interface
    rl.close();
});
