// Function to format time units to always show two digits
function formatTimeUnit(unit) {
    return unit < 10 ? '0' + unit : unit;
}

// current date and time
const now = new Date();
const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const dayName = daysOfWeek[now.getDay()]; // Get the current day name
const hours = now.getHours();
const minutes = now.getMinutes();
const seconds = now.getSeconds();

// Convert 24-hour time to 12-hour time with AM/PM
const period = hours >= 12 ? 'PM' : 'AM';
const formattedHours = hours % 12 || 12; // Convert 24-hour format to 12-hour format

// Create the time string
const timeString = `Today is : ${dayName}. Current time is : ${formattedHours} ${period} : ${formatTimeUnit(minutes)} : ${formatTimeUnit(seconds)}`;

// Display the result
console.log(timeString);
