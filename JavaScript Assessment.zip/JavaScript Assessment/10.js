function sortStringAlphabetically(str) {
    // Convert the string to an array of characters
    const charArray = str.split('');
    
    // Sort the array in alphabetical order
    const sortedArray = charArray.sort();
    
    // Join the sorted array back into a string
    const sortedStr = sortedArray.join('');
    
    return sortedStr;
}

const inputString = 'webmaster';
console.log(`Original String: ${inputString}`);
console.log(`Sorted String: ${sortStringAlphabetically(inputString)}`); // Output: 'abeemrstw'
