function repeatLastThreeChars(originalString) {
    // Check if the length of the string is at least 3
    if (originalString.length < 3) {
        return false;
    }

    // Extract the last 3 characters
    const lastThreeChars = originalString.slice(-3);

    // Create the new string by repeating the last 3 characters 4 times
    const result = lastThreeChars.repeat(4);

    return result;
}

// inputs and outputs
const input1 = "Python 3.0";
const input2 = "JS";
const input3 = "JavaScript";

console.log(`Input: ${input1}`);
console.log(`Output: ${repeatLastThreeChars(input1)}`); // Output: 3.03.03.03.0

console.log(`Input: ${input2}`);
console.log(`Output: ${repeatLastThreeChars(input2)}`); // Output: false

console.log(`Input: ${input3}`);
console.log(`Output: ${repeatLastThreeChars(input3)}`); // Output: iptiptiptipt
