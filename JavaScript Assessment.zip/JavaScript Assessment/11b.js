function countLetterOccurrences(str) {
    // Create a map to store letter occurrences
    const letterCounts = new Map();

    // Convert the string to lowercase to make the count case-insensitive
    const lowerStr = str.toLowerCase();

    // Iterate through each character in the string
    for (const char of lowerStr) {
        // Check if the character is a letter
        if (char >= 'a' && char <= 'z') {
            // Increment the count of the letter in the map
            letterCounts.set(char, (letterCounts.get(char) || 0) + 1);
        }
    }

    // Convert the map to an object for easier display
    const result = {};
    for (const [key, value] of letterCounts) {
        result[key] = value;
    }

    return result;
}

// Example usage
const inputString = 'The quick brown fox jumps over the lazy dog';
const occurrences = countLetterOccurrences(inputString);

// Format the output as specified
const formattedOutput = Object.entries(occurrences)
    .map(([key, value]) => `"${key}":${value}`)
    .join(',');

console.log(formattedOutput);
