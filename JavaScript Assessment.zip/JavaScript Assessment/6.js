function hasEqualPsAndSs(str) {
    // Convert the string to lowercase to handle case insensitivity
    const lowerStr = str.toLowerCase();
    
    // Count occurrences of 'p' and 's'
    const pCount = (lowerStr.match(/p/g) || []).length;
    const sCount = (lowerStr.match(/s/g) || []).length;

    // Compare the counts
    return pCount === sCount;
}

// Example usage
const inputString1 = "paatpss";
const inputString2 = "paatps";

console.log(`Input string: ${inputString1}`);
console.log(`Output: ${hasEqualPsAndSs(inputString1)}`); // Output: true

console.log(`Input string: ${inputString2}`);
console.log(`Output: ${hasEqualPsAndSs(inputString2)}`); // Output: false
