function longestUniqueSubstring(s) {
    let start = 0; // Start index of the sliding window
    let maxLength = 0; // Length of the longest substring found
    let maxSubstring = ''; // The longest substring itself
    let charSet = new Set(); // Set to keep track of characters in the current window

    for (let end = 0; end < s.length; end++) {
        while (charSet.has(s[end])) {
            // If the character is already in the set, remove the start character and move the window
            charSet.delete(s[start]);
            start++;
        }

        // Add the current character to the set
        charSet.add(s[end]);

        // Update the maximum length and substring if the current window is larger
        if (end - start + 1 > maxLength) {
            maxLength = end - start + 1;
            maxSubstring = s.substring(start, end + 1);
        }
    }

    return maxSubstring;
}

const input1 = 'google.com';
const input2 = 'example.com';

console.log(longestUniqueSubstring(input1)); 
console.log(longestUniqueSubstring(input2)); 
