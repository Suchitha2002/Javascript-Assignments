function findLongestWord(str) {
    // Split the string into an array of words
    const words = str.split(' ');
    
    // Use reduce to find the longest word
    const longestWord = words.reduce((longest, current) => {
        return current.length > longest.length ? current : longest;
    }, '');
    
    return longestWord;
}

// Example usage
const exampleString1 = 'Web Development Tutorial';
console.log(findLongestWord(exampleString1)); // Output: 'Development'
