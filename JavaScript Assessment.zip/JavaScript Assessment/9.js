function reverseNumber(num) {
    // Convert the number to a string
    const numStr = num.toString();
    
    // Reverse the string
    const reversedStr = numStr.split('').reverse().join('');
    
    // Convert the reversed string back to a number
    const reversedNum = parseInt(reversedStr, 10);
    
    return reversedNum;
}

// Example usage
const number = 32243;
console.log(`Original Number: ${number}`);
console.log(`Reversed Number: ${reverseNumber(number)}`); // Output: 34223
