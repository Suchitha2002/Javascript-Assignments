// Function to format time units to always show two digits
function formatTimeUnit(unit) {
    return unit < 10 ? '0' + unit : unit;
}

// current date
const now = new Date();

// date components
const month = formatTimeUnit(now.getMonth() + 1); // Months are 0-based, so add 1
const day = formatTimeUnit(now.getDate());
const year = now.getFullYear();

// date in various styles
const format1 = `${month}-${day}-${year}`; // mm-dd-yyyy
const format2 = `${month}/${day}/${year}`; // mm/dd/yyyy
const format3 = `${day}-${month}-${year}`; // dd-mm-yyyy
const format4 = `${day}/${month}/${year}`; // dd/mm/yyyy

// Display the results
console.log("Date in mm-dd-yyyy format: " + format1);
console.log("Date in mm/dd/yyyy format: " + format2);
console.log("Date in dd-mm-yyyy format: " + format3);
console.log("Date in dd/mm/yyyy format: " + format4);
